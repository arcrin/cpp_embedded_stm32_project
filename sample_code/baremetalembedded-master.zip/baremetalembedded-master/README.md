# baremetalembedded
Understanding build procedure and linker script for bare metal embedded systems(ARM Cortex Mx)
